package sample;

public class InvalidMapException extends Exception {
    public InvalidMapException(String s){
        super(s);
    }
}
